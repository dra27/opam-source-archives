let version = "1.8.4+dev"
let date = "Fri Apr 4 14:45:42 CEST 2014"
