let version = "1.8.6"
let date = "Fri Jan 23 08:23:33 CET 2015"
